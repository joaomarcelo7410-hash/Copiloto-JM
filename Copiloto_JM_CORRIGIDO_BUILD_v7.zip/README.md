# Copiloto JM — v5 — correção de dependências para gerar APK

## Como usar
1. Extraia este ZIP e envie todos os arquivos para o repositório GitHub (na raiz).
2. Abra a aba **Actions**.
3. Selecione **Gerar APK Copiloto JM** e clique em **Run workflow** (ou aguarde o push na branch main).
4. Quando o workflow terminar com sucesso, abra a execução e baixe o artefato **Copiloto-JM-APK**.

## Correção aplicada
- Forçada globalmente a versão `androidx.exifinterface:exifinterface:1.3.7` e excluída a versão transitiva antiga do ML Kit, adicionando a versão moderna explicitamente.
- Incluída a dependência explícita da versão corrigida.
- Atualizado versionCode/versionName.
- Workflow usa Java 17, Gradle 8.9 e Android SDK 35, com compilação limpa.

Se o build continuar falhando, envie o trecho do log que começa em `FAILURE: Build failed` e a linha `Could not...`.
