# Copiloto JM — versão corrigida para gerar APK

## Como usar
1. Extraia este ZIP e envie todos os arquivos para o repositório GitHub (na raiz).
2. Abra a aba **Actions**.
3. Selecione **Gerar APK Copiloto JM** e clique em **Run workflow** (ou aguarde o push na branch main).
4. Quando o workflow terminar com sucesso, abra a execução e baixe o artefato **Copiloto-JM-APK**.

## Correção aplicada
- Fixada a dependência `androidx.exifinterface:exifinterface` em `1.3.7`, evitando a resolução da versão antiga `1.0.0` que aparece no erro do build.
- Incluída a dependência explícita da versão corrigida.
- Atualizado versionCode/versionName.
- Workflow usa Java 17, Gradle 8.9 e Android SDK 35, com compilação limpa.

Se o build continuar falhando, envie o trecho do log que começa em `FAILURE: Build failed` e a linha `Could not...`.
