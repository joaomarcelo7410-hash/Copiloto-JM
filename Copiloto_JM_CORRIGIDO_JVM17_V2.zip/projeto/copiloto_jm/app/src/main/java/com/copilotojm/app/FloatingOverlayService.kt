package com.copilotojm.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class FloatingOverlayService : Service() {
 private var windowManager: WindowManager?=null
 private var panel: TextView?=null
 private val br=NumberFormat.getCurrencyInstance(Locale("pt","BR"))
 override fun onStartCommand(intent: Intent?,flags:Int,startId:Int):Int {
  removePanel(); windowManager=getSystemService(WINDOW_SERVICE) as WindowManager
  val v=intent?.getStringExtra("verdict") ?: "REVIEW"
  val f=intent?.getDoubleExtra("fare",0.0) ?: 0.0
  val d=intent?.getDoubleExtra("distance",0.0) ?: 0.0
  val pk=intent?.getDoubleExtra("perKm",0.0) ?: 0.0
  val fuel=intent?.getDoubleExtra("fuel",0.0) ?: 0.0
  val net=intent?.getDoubleExtra("net",0.0) ?: 0.0
  val reason=intent?.getStringExtra("reason") ?: "Aguardando oferta"
  val label=when(v) { "GOOD"->"🟢 BOA"; "BAD"->"🔴 RUIM"; else->"🟡 AVALIAR" }
  panel=TextView(this).apply {
   text="COPILOTO JM • $label\n${br.format(f)} | ${d} km | ${br.format(pk)}/km\nCombustível ${br.format(fuel)} • Líquido ${br.format(net)}\n$reason\nTOQUE PARA FECHAR"
   setTextColor(Color.WHITE); textSize=13f; setPadding(24,18,24,18); setBackgroundColor(Color.rgb(35,35,40))
   setOnClickListener { stopSelf() }
  }
  val params=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
   WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
   WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
   PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=20; y=160 }
  windowManager?.addView(panel,params); return START_NOT_STICKY
 }
 private fun removePanel(){ panel?.let { try { windowManager?.removeView(it) } catch (_:Exception){} }; panel=null }
 override fun onDestroy(){removePanel();super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
