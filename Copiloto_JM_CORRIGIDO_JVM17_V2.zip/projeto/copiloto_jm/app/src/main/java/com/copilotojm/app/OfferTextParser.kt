package com.copilotojm.app

data class ParsedOffer(val fare: Double?, val distanceKm: Double?, val minutes: Double?, val rawText: String)

object OfferTextParser {
    private fun parseNumber(raw: String): Double? {
        val s = raw.trim().replace(" ", "")
        // OCR may return Brazilian decimal comma or decimal point.
        return if (s.contains(',') && s.contains('.')) {
            s.replace(".", "").replace(',', '.').toDoubleOrNull()
        } else s.replace(',', '.').toDoubleOrNull()
    }

    fun parse(text: String): ParsedOffer {
        val normalized = Regex("\\s+").replace(text, " ")
        val currency = Regex("R\\$\\s*(\\d{1,4}(?:[.,]\\d{1,2})?)", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.let(::parseNumber)?.takeIf { it in 2.0..1000.0 }
        val km = Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:km|quil[oô]metros?)", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.let(::parseNumber)?.takeIf { it in 0.1..300.0 }
        val mins = Regex("(\\d{1,3})\\s*(?:min(?:utos?)?)", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.toDoubleOrNull()?.takeIf { it in 1.0..300.0 }

        // Fallback only when currency symbol was missed by OCR: avoid km/min values and choose a plausible amount.
        val fare = currency ?: Regex("(?<![\\w])(\\d{1,4}(?:[.,]\\d{2})?)(?![\\w])")
            .findAll(normalized).mapNotNull { it.groupValues[1].let(::parseNumber) }
            .filter { it in 3.0..500.0 && it != km && it != mins }
            .maxOrNull()
        return ParsedOffer(fare, km, mins, text)
    }
}
