package com.copilotojm.app

data class RaceAnalysis(
    val fare: Double, val distanceKm: Double, val minutes: Double,
    val fuelCost: Double, val netAfterFuel: Double, val perKm: Double,
    val perHour: Double, val verdict: Verdict, val reason: String
)

enum class Verdict { GOOD, REVIEW, BAD }

object RaceCalculator {
    fun analyze(
        fare: Double, distanceKm: Double, minutes: Double, fuelPrice: Double,
        kmPerLiter: Double, minPerKmGood: Double = 2.0,
        minPerKmReview: Double = 1.5, minNetGood: Double = 8.0
    ): RaceAnalysis {
        require(fare > 0 && distanceKm > 0 && minutes > 0 && fuelPrice > 0 && kmPerLiter > 0) {
            "Os valores precisam ser maiores que zero."
        }
        val fuelCost = (distanceKm / kmPerLiter) * fuelPrice
        val net = fare - fuelCost
        val perKm = fare / distanceKm
        val perHour = net / minutes * 60.0
        val verdict = when {
            perKm >= minPerKmGood && net >= minNetGood -> Verdict.GOOD
            perKm >= minPerKmReview && net > 0 -> Verdict.REVIEW
            else -> Verdict.BAD
        }
        val reason = when (verdict) {
            Verdict.GOOD -> "Boa relação valor/km e lucro após combustível."
            Verdict.REVIEW -> "Corrida positiva, mas avalie tempo, trânsito e retorno."
            Verdict.BAD -> "Baixa rentabilidade ou lucro insuficiente após combustível."
        }
        return RaceAnalysis(fare, distanceKm, minutes, fuelCost, net, perKm, perHour, verdict, reason)
    }
}
