# Copiloto JM v0.4 — arquivos prontos para GitHub

Este pacote está organizado para ser colocado **diretamente na raiz** do repositório GitHub.

## Como substituir no GitHub pelo celular

1. Baixe e extraia este ZIP no celular.
2. No repositório `Copiloto-JM`, remova os arquivos/pastas antigos que pertencem ao projeto e ao workflow antigo.
3. Faça upload dos arquivos e pastas extraídos, mantendo a estrutura (incluindo `.github/workflows/main.yml`).
4. Faça commit diretamente na branch `main`.
5. Abra **Actions** e a execução **Gerar APK Copiloto JM**.
6. Quando ficar verde, abra a execução e baixe o artifact `Copiloto-JM-APK`.

## Estrutura

- `app/` — aplicativo Android
- `build.gradle` — configuração de plugins
- `settings.gradle` — configuração do projeto
- `.github/workflows/main.yml` — build automático do APK

O workflow compila o projeto diretamente, sem precisar enviar outro ZIP do aplicativo ou extrair ZIP dentro do GitHub Actions.
