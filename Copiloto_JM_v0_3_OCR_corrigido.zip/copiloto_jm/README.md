# Copiloto JM — versão 0.3 (OCR experimental)

## Novidades
- Botão "Ler oferta na tela (captura)".
- Solicita permissão de captura de tela Android (MediaProjection) e captura um frame.
- OCR local via ML Kit Text Recognition (Latin).
- Parser experimental tenta localizar valor (R$), distância (km) e tempo (min).
- Preenche os campos; quando consegue todos, calcula automaticamente. Confira os valores reconhecidos antes de usar.
- Dependência ML Kit adicionada.

## Limitações importantes
- É captura manual de uma tela, não monitoramento contínuo. Android exige consentimento para captura.
- OCR/parser pode confundir preço, km e tempo dependendo do layout ou idioma. Sempre confira a oferta antes de decidir.
- Não lê automaticamente ou interage/aceita/recusa corridas.
- O painel flutuante exibe a última análise.
- Lucro desconta combustível apenas; outros custos não incluídos.

## Build
Abra no Android Studio e sincronize Gradle. Compile APK (Build > Build APK). Não foi compilado neste ambiente.
