package com.copilotojm.app

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val br = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
    private lateinit var fuelPrice: EditText
    private lateinit var kmPerLiter: EditText
    private lateinit var dailyGoal: EditText
    private lateinit var fare: EditText
    private lateinit var distance: EditText
    private lateinit var minutes: EditText
    private lateinit var verdict: TextView
    private lateinit var reason: TextView
    private lateinit var results: TextView
    private lateinit var dailyProgress: TextView
    private var latest: RaceAnalysis? = null
    private var dailyNet = 0.0

    private val ocrReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("ocrText") ?: return
            if (text.startsWith("Não foi possível") || text.startsWith("Falha no OCR")) {
                Toast.makeText(this@MainActivity, text, Toast.LENGTH_LONG).show()
                return
            }
            val parsed = OfferTextParser.parse(text)
            parsed.fare?.let { fare.setText(String.format(Locale.US, "%.2f", it).replace(".", ",")) }
            parsed.distanceKm?.let { distance.setText(String.format(Locale.US, "%.1f", it).replace(".", ",")) }
            parsed.minutes?.let { minutes.setText(it.toInt().toString()) }
            val missing = mutableListOf<String>()
            if (parsed.fare == null) missing.add("valor")
            if (parsed.distanceKm == null) missing.add("distância")
            if (parsed.minutes == null) missing.add("tempo")
            if (missing.isNotEmpty()) {
                Toast.makeText(this@MainActivity, "OCR encontrou parte da oferta. Complete: ${missing.joinToString()}.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@MainActivity, "Oferta lida! Confira os campos e toque em ANALISAR.", Toast.LENGTH_LONG).show()
                analyze()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        fuelPrice=findViewById(R.id.fuelPrice); kmPerLiter=findViewById(R.id.kmPerLiter)
        dailyGoal=findViewById(R.id.dailyGoal); fare=findViewById(R.id.fare)
        distance=findViewById(R.id.distance); minutes=findViewById(R.id.minutes)
        verdict=findViewById(R.id.verdict); reason=findViewById(R.id.reason)
        results=findViewById(R.id.results); dailyProgress=findViewById(R.id.dailyProgress)
        val prefs=getSharedPreferences("copiloto", MODE_PRIVATE)
        fuelPrice.setText(prefs.getString("fuel","7,00")); kmPerLiter.setText(prefs.getString("consumption","10"))
        dailyGoal.setText(prefs.getString("goal","250")); dailyNet=prefs.getFloat("dailyNet",0f).toDouble()
        updateGoal()
        findViewById<Button>(R.id.analyzeButton).setOnClickListener { analyze() }
        findViewById<Button>(R.id.overlayButton).setOnClickListener { activateOverlay() }
        findViewById<Button>(R.id.captureButton).setOnClickListener { requestScreenCapture() }
    }

    override fun onResume() {
        super.onResume()
        val filter=IntentFilter("com.copilotojm.OCR_RESULT")
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(ocrReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(ocrReceiver, filter)
    }
    override fun onPause() {
        try { unregisterReceiver(ocrReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    private fun requestScreenCapture() {
        val manager=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), 410)
    }
    @Deprecated("Legacy result handler retained for broad device compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode==410 && resultCode==RESULT_OK && data!=null) {
            val service=Intent(this,ScreenCaptureService::class.java)
            service.putExtra("resultCode",resultCode)
            service.putExtra("projectionData",data)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        } else if (requestCode==410) {
            Toast.makeText(this,"Captura cancelada.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun number(edit: EditText): Double = edit.text.toString().trim().replace(",",".").toDoubleOrNull() ?: 0.0
    private fun analyze() {
        val f=number(fare); val d=number(distance); val t=number(minutes)
        val fuel=number(fuelPrice); val consumption=number(kmPerLiter)
        if (f<=0 || d<=0 || t<=0 || fuel<=0 || consumption<=0) {
            Toast.makeText(this,"Preencha valor, km, tempo e configurações válidas.",Toast.LENGTH_LONG).show(); return
        }
        getSharedPreferences("copiloto",MODE_PRIVATE).edit().putString("fuel",fuelPrice.text.toString())
            .putString("consumption",kmPerLiter.text.toString()).putString("goal",dailyGoal.text.toString()).apply()
        val a=RaceCalculator.analyze(f,d,t,fuel,consumption); latest=a
        when(a.verdict) {
            Verdict.GOOD -> { verdict.text="🟢 CORRIDA BOA"; verdict.setTextColor(0xFF4ADE80.toInt()) }
            Verdict.REVIEW -> { verdict.text="🟡 AVALIAR"; verdict.setTextColor(0xFFFFD54F.toInt()) }
            Verdict.BAD -> { verdict.text="🔴 CORRIDA RUIM"; verdict.setTextColor(0xFFFF6B6B.toInt()) }
        }
        reason.text=a.reason
        results.text="Valor: ${br.format(f)}\nDistância: ${d} km\nValor por km: ${br.format(a.perKm)}\nCombustível estimado: ${br.format(a.fuelCost)}\nLucro após combustível: ${br.format(a.netAfterFuel)}\nEstimativa por hora: ${br.format(a.perHour)}"
        updateGoal()
    }
    private fun updateGoal() {
        val goal=number(dailyGoal).takeIf { it>0 } ?: 250.0
        dailyProgress.text="Meta líquida: ${br.format(goal)} • Acumulado: ${br.format(dailyNet)} • Falta: ${br.format((goal-dailyNet).coerceAtLeast(0.0))}"
    }
    private fun activateOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))); return
        }
        val a=latest
        val intent=Intent(this,FloatingOverlayService::class.java)
        if (a!=null) {
            intent.putExtra("verdict",a.verdict.name); intent.putExtra("fare",a.fare)
            intent.putExtra("distance",a.distanceKm); intent.putExtra("perKm",a.perKm)
            intent.putExtra("fuel",a.fuelCost); intent.putExtra("net",a.netAfterFuel); intent.putExtra("reason",a.reason)
        }
        startService(intent)
        Toast.makeText(this,"Painel flutuante ativado. Toque nele para fechar.",Toast.LENGTH_SHORT).show()
    }
}
