package com.copilotojm.app

data class ParsedOffer(val fare: Double?, val distanceKm: Double?, val minutes: Double?, val rawText: String)

object OfferTextParser {
    fun parse(text: String): ParsedOffer {
        val normalized = Regex("\\s+").replace(text, " ")
        val fareRegex = Regex("(?:R\\$\\s*)?(\\d{1,3}(?:[.,]\\d{2})|\\d{1,3})")
        val fareCandidates = fareRegex.findAll(normalized).mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }
            .filter { it in 3.0..500.0 }.toList()
        // Prefer an amount explicitly adjacent to R$, otherwise use the largest plausible offer amount.
        val currency = Regex("R\\$\\s*(\\d+(?:[.,]\\d{2})?)", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.replace(",", ".")?.toDoubleOrNull()
        val fare = currency ?: fareCandidates.maxOrNull()
        val km = Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:km|quil[oô]metros?)", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.replace(",", ".")?.toDoubleOrNull()
        val mins = Regex("(\\d+)\\s*(?:min|minutos?)", RegexOption.IGNORE_CASE)
            .find(normalized)?.groupValues?.get(1)?.toDoubleOrNull()
        return ParsedOffer(fare, km, mins, text)
    }
}
