package com.copilotojm.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.common.InputImage

class ScreenCaptureService : Service() {
    private var projection: android.media.projection.MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(42, notification())
        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("projectionData")
        if (resultCode == 0 || data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        captureOneFrame()
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val channel = "copiloto_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(channel, "Captura de tela", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Copiloto JM")
            .setContentText("Captura de tela para analisar oferta")
            .setOngoing(true).build()
    }

    private fun captureOneFrame() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "CopilotoJM-Capture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null
        )
        Handler(Looper.getMainLooper()).postDelayed({
            val image = reader?.acquireLatestImage()
            if (image == null) {
                sendResult("Não foi possível capturar a tela. Tente novamente.")
                stopSelf(); return@postDelayed
            }
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width
            val bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
            image.close(); bitmap.recycle()
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(cropped, 0))
                .addOnSuccessListener { visionText ->
                    sendResult(visionText.text)
                    cropped.recycle()
                }
                .addOnFailureListener { sendResult("Falha no OCR: ${it.message}"); cropped.recycle() }
                .addOnCompleteListener { stopSelf() }
        }, 650)
    }

    private fun sendResult(text: String) {
        val i = Intent("com.copilotojm.OCR_RESULT")
        i.setPackage(packageName)
        i.putExtra("ocrText", text)
        sendBroadcast(i)
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
