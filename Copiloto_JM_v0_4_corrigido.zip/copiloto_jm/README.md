# Copiloto JM — versão 0.4 corrigida

Aplicativo Android para analisar ofertas de corridas Uber/99 manualmente.

## Recursos
- Cálculo de valor por km, custo estimado de combustível, lucro após combustível e estimativa líquida por hora.
- Classificação: BOA / AVALIAR / RUIM.
- OCR manual de uma captura autorizada da tela via ML Kit.
- Painel flutuante para mostrar a última análise.
- Meta diária com acumulado: botão **Registrar corrida** soma o lucro estimado da corrida analisada; **Zerar acumulado** reinicia o total.
- Preferências de combustível, consumo e meta salvas localmente.

## Limitações
- OCR é manual e pode reconhecer números incorretamente; revise todos os campos.
- Não monitora corridas continuamente, não aceita/recusa ofertas e não interage com Uber/99.
- O cálculo desconta apenas combustível; não inclui manutenção, depreciação, pedágios, deslocamento vazio ou outros custos.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Android Studio > **Open** > selecione a pasta `copiloto_jm`.
3. Aguarde sincronização Gradle.
4. Build > Build APK(s).

## Gerar APK pelo GitHub Actions
O projeto inclui `.github/workflows/build-apk.yml`. Ao enviar o projeto ao repositório GitHub, o workflow roda no push para `main` ou manualmente em Actions > Build Copiloto JM APK > Run workflow. Quando finalizar com sucesso, abra a execução e baixe o artifact **Copiloto-JM-APK**.

## Versão
0.4 — corrigidos fluxo de captura/OCR e gerenciamento de recursos, parser mais robusto, registro de corrida no acumulado diário e workflow de build simplificado.
